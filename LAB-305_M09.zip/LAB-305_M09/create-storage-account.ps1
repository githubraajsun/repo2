<#	
	Version:        1.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  20th May, 2022
	Purpose/Change: Create Storage account & Private endpoint

#>

############################################## Variables ##################################################################
# Variables for common values
$resourceGroup = "az-305-09-rg"
$location= "eastus"
$SkuName = "Standard_LRS"
$Prefix = "inventorystg"
$indexdoc = "index.html"
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

############################################## Storage account ############################################################
#Create Storageaccount
function New-RandomName {
( -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 10 | % {[char]$_}))
}
do {
        $SARandomName = New-RandomName
        $SAName = ($Prefix + $SARandomName).ToLower()
        $Availability = Get-AzStorageAccountNameAvailability -Name $SAName
    }
while ($Availability.NameAvailable -eq $false)
    
$storageAccount = New-AzStorageAccount -resourceGroupName $resourceGroup -Name $SAName -location $location -SkuName $SkuName

########################################### Enable Static Website #########################################################

Enable-AzStorageStaticWebsite -Context $StorageAccount.Context -IndexDocument $indexdoc

# End
